create trigger delete_comment_like
  after DELETE
  on comments
  for each row
  DELETE FROM likes
 WHERE owner_id = OLD.owner_id
 AND entity_id=OLD.id AND type = 2;

