create trigger delete_follows_action
  before DELETE
  on friendships
  for each row
  DELETE FROM actions WHERE receiver_id=OLD.user_id AND initiator_id=OLD.subscriber_id AND type=3 AND entity_id=OLD.subscriber_id;

