create trigger delete_post_like
  after DELETE
  on posts
  for each row
  DELETE FROM likes
WHERE owner_id = OLD.owner_id
AND entity_id=OLD.id AND type = 1;

