create trigger add_like_action
  after INSERT
  on likes
  for each row
  INSERT INTO actions (receiver_id, initiator_id, type, entity_id, created_at) VALUES(IF(NEW.type=1, (SELECT owner_id FROM posts WHERE id=NEW.entity_id), (SELECT owner_id FROM comments WHERE id=NEW.entity_id)), NEW.owner_id, 1, NEW.id, NOW());

