create trigger add_comment_action
  before INSERT
  on comments
  for each row
  INSERT INTO actions (receiver_id, initiator_id, type, entity_id) VALUES((SELECT owner_id FROM posts WHERE id=new.post_id), NEW.owner_id, 2, NEW.post_id);

