create trigger delete_comment_action
  before DELETE
  on comments
  for each row
  DELETE FROM actions WHERE receiver_id = (SELECT owner_id FROM posts WHERE OLD.post_id) AND initiator_id=OLD.owner_id AND type=2 AND entity_id=OLD.id;

