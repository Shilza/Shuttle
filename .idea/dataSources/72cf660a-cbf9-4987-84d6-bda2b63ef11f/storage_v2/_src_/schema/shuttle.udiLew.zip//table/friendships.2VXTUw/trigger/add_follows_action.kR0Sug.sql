create trigger add_follows_action
  after INSERT
  on friendships
  for each row
  INSERT INTO actions (receiver_id, initiator_id, type, entity_id, created_at) VALUES(NEW.user_id, NEW.subscriber_id, 3, NEW.subscriber_id, NOW());

